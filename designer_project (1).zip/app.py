from flask import Flask, render_template, request, redirect, url_for
import sqlite3
import os
from werkzeug.utils import secure_filename

app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = 'static/uploads/'
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)

# إنشاء قاعدة البيانات والجداول لو مش موجودة
def init_db():
    with sqlite3.connect('designers.db') as conn:
        c = conn.cursor()
        c.execute('''
            CREATE TABLE IF NOT EXISTS designers (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT,
                specialty TEXT,
                contact TEXT,
                sample TEXT
            )
        ''')
        c.execute('''
            CREATE TABLE IF NOT EXISTS requests (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                client_name TEXT,
                design_type TEXT,
                description TEXT,
                contact TEXT
            )
        ''')
        conn.commit()

init_db()

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/designers')
def designers():
    with sqlite3.connect('designers.db') as conn:
        c = conn.cursor()
        c.execute("SELECT name, specialty, contact, sample FROM designers")
        all_designers = [
            {'name': row[0], 'specialty': row[1], 'contact': row[2], 'sample': row[3]}
            for row in c.fetchall()
        ]
    return render_template('designers.html', designers=all_designers)

@app.route('/register_designer', methods=['GET', 'POST'])
def register_designer():
    if request.method == 'POST':
        name = request.form['name']
        specialty = request.form['specialty']
        contact = request.form['contact']
        file = request.files['sample']
        filename = secure_filename(file.filename)
        file_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        file.save(file_path)

        with sqlite3.connect('designers.db') as conn:
            c = conn.cursor()
            c.execute("INSERT INTO designers (name, specialty, contact, sample) VALUES (?, ?, ?, ?)",
                      (name, specialty, contact, file_path.replace('static/', '')))
            conn.commit()
        return redirect(url_for('designers'))
    return render_template('register.html')

@app.route('/request_design', methods=['GET', 'POST'])
def request_design():
    if request.method == 'POST':
        client_name = request.form['client_name']
        design_type = request.form['design_type']
        description = request.form['description']
        contact = request.form['contact']

        with sqlite3.connect('designers.db') as conn:
            c = conn.cursor()
            c.execute("INSERT INTO requests (client_name, design_type, description, contact) VALUES (?, ?, ?, ?)",
                      (client_name, design_type, description, contact))
            conn.commit()
        return redirect(url_for('home'))
    return render_template('request.html')

if __name__ == '__main__':
    app.run(debug=True)

